from keres import *


class Kancsok(Feladat):
    def __init__(self, kezdő, cél, max1=3, max2=5, max3=8):
        self.kezdő = kezdő
        self.cél = cél
        self.max1 = max1
        self.max2 = max2
        self.max3 = max3

    def célteszt(self, állapot):
        return (
            állapot[0] == self.cél
            or állapot[1] == self.cél
            or állapot[2] == self.cél
        )

    def rákövetkező(self, állapot):
        gyerekek = []
        menny = list(állapot)
        maxok = [self.max1, self.max2, self.max3]

        for src in range(3):
            if menny[src] == 0:
                continue
            for dst in range(3):
                if src == dst or menny[dst] == maxok[dst]:
                    continue
                t = min(menny[src], maxok[dst] - menny[dst])
                uj = list(menny)
                uj[src] -= t
                uj[dst] += t
                gyerekek.append((f"tölt {src + 1}-ból {dst + 1}-be", tuple(uj)))

        return gyerekek


if __name__ == "__main__":
    feladat = Kancsok((0, 0, 8), 4)
    print("Szélességi gráfkereső")
    result = szélességi_gráfkereső(feladat)
    print(result.megoldás())
    utam = result.út()
    utam.reverse()
    print(utam)
